package com.SmsService.Twilio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TwilioApplicationTests {

	@Test
	void contextLoads() {
	}

}
